def printToFile(f, str):
    print(str, file=f)
