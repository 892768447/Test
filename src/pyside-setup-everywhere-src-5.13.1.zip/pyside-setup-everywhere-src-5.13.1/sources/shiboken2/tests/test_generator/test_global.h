struct Dummy {};
