# Shiboken Documentation

The documentation was written and needs to be generated
with [python-sphinx](http://www.sphinx-doc.org/en/master/)

### Images

The SVG diagrams use the Qt color scheme.
The font also follows Qt styling, and it is called `Titillium`.
It can be download from:
* https://fonts.google.com/specimen/Titillium+Web
* https://www.fontsquirrel.com/fonts/Titillium
